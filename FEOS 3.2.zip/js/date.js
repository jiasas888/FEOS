var dates = new Date()
var spana = document.getElementById("spana");
var spanb = document.getElementById("spanb");
var spanc = document.getElementById("spanc");
var H = dates.getHours();
var M = dates.getMinutes();
var S = dates.getSeconds();
spana.innerHTML = H;
spanb.innerHTML = M;
spanc.innerHTML = S;
var Time = function (){
var dates = new Date()
var spana = document.getElementById("spana");
var spanb = document.getElementById("spanb");
var spanc = document.getElementById("spanc");
var H = dates.getHours();
var M = dates.getMinutes();
var S = dates.getSeconds();
spana.innerHTML = H;
spanb.innerHTML = M;
spanc.innerHTML = S;
};
setInterval(Time,1000);